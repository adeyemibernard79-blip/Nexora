package com.nexora.play.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

val Violet = Color(0xFF7C5CFF)
val Cyan = Color(0xFF00E5FF)

private val Scheme = darkColorScheme(
    primary = Violet, secondary = Cyan,
    background = Color(0xFF070A14), surface = Color(0xFF0F1424),
    onBackground = Color(0xFFEAF0FF), onSurface = Color(0xFFEAF0FF),
)

@Composable
fun NexoraTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, content = content)

/** Cheap "glass": translucent fill + hairline border (real blur is too costly on a Helio G81). */
fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp)) = this
    .clip(shape)
    .background(Color.White.copy(alpha = 0.06f))
    .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
