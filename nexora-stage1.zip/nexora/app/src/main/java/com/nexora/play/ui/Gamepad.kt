package com.nexora.play.ui

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexora.play.data.GameSystem
import kotlin.math.roundToInt

@Composable
fun PadButton(
    label: String, size: Dp, modifier: Modifier = Modifier, shape: Shape = CircleShape, width: Dp = size,
    onKey: (Boolean) -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    Box(
        modifier
            .size(width, size).clip(shape)
            .background(if (pressed) Violet.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.18f))
            .border(1.dp, Color.White.copy(alpha = 0.35f), shape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed = true; onKey(true)
                    try { tryAwaitRelease() } finally { pressed = false; onKey(false) }
                })
            },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 16.sp) }
}

@Composable
fun Stick(size: Dp, onMove: (Float, Float) -> Unit) {
    var off by remember { mutableStateOf(Offset.Zero) }
    val r = with(LocalDensity.current) { (size / 2).toPx() }
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { off = Offset.Zero; onMove(0f, 0f) },
                    onDragCancel = { off = Offset.Zero; onMove(0f, 0f) },
                ) { change, drag ->
                    change.consume()
                    var n = off + drag
                    val len = n.getDistance()
                    if (len > r) n = n * (r / len)
                    off = n
                    onMove(n.x / r, n.y / r)
                }
            },
    ) {
        Box(
            Modifier.align(Alignment.Center)
                .offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }
                .size(size / 2).clip(CircleShape).background(Violet.copy(alpha = 0.7f))
        )
    }
}

/** Draws the on-screen controller. [key] receives (android keycode, isDown); [stick] receives x,y in -1..1. */
@Composable
fun Gamepad(
    system: GameSystem, opacity: Float,
    key: (Int, Boolean) -> Unit, stick: (Float, Float) -> Unit,
) {
    var stickMode by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp).alpha(opacity)) {
        // Left cluster: D-pad (or analog stick on PSP, toggled)
        Box(Modifier.align(Alignment.BottomStart).padding(bottom = 24.dp)) {
            if (stickMode && system.hasAnalog) {
                Stick(140.dp, stick)
            } else {
                Box(Modifier.size(150.dp)) {
                    PadButton("\u25B2", 50.dp, Modifier.align(Alignment.TopCenter)) { key(KeyEvent.KEYCODE_DPAD_UP, it) }
                    PadButton("\u25BC", 50.dp, Modifier.align(Alignment.BottomCenter)) { key(KeyEvent.KEYCODE_DPAD_DOWN, it) }
                    PadButton("\u25C0", 50.dp, Modifier.align(Alignment.CenterStart)) { key(KeyEvent.KEYCODE_DPAD_LEFT, it) }
                    PadButton("\u25B6", 50.dp, Modifier.align(Alignment.CenterEnd)) { key(KeyEvent.KEYCODE_DPAD_RIGHT, it) }
                }
            }
        }
        if (system.hasAnalog) {
            PadButton(
                if (stickMode) "D-pad" else "Stick", 32.dp, Modifier.align(Alignment.BottomStart).offset(y = 6.dp),
                shape = RoundedCornerShape(16.dp), width = 64.dp,
            ) { if (it) stickMode = !stickMode }
        }
        // Right cluster: face buttons. Android keycodes are positional: A=bottom, B=right, X=left, Y=top.
        Box(Modifier.align(Alignment.BottomEnd).padding(bottom = 24.dp).size(150.dp)) {
            PadButton(system.face[0], 52.dp, Modifier.align(Alignment.BottomCenter)) { key(KeyEvent.KEYCODE_BUTTON_A, it) }
            PadButton(system.face[1], 52.dp, Modifier.align(Alignment.CenterEnd)) { key(KeyEvent.KEYCODE_BUTTON_B, it) }
            PadButton(system.face[2], 52.dp, Modifier.align(Alignment.CenterStart)) { key(KeyEvent.KEYCODE_BUTTON_X, it) }
            PadButton(system.face[3], 52.dp, Modifier.align(Alignment.TopCenter)) { key(KeyEvent.KEYCODE_BUTTON_Y, it) }
        }
        // Shoulders
        val pill = RoundedCornerShape(14.dp)
        Column(Modifier.align(Alignment.TopStart).padding(top = 52.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            PadButton("L", 34.dp, shape = pill, width = 70.dp) { key(KeyEvent.KEYCODE_BUTTON_L1, it) }
            if (system.hasL2R2) PadButton("L2", 34.dp, shape = pill, width = 70.dp) { key(KeyEvent.KEYCODE_BUTTON_L2, it) }
        }
        Column(Modifier.align(Alignment.TopEnd).padding(top = 52.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            PadButton("R", 34.dp, shape = pill, width = 70.dp) { key(KeyEvent.KEYCODE_BUTTON_R1, it) }
            if (system.hasL2R2) PadButton("R2", 34.dp, shape = pill, width = 70.dp) { key(KeyEvent.KEYCODE_BUTTON_R2, it) }
        }
        // Start / Select
        Row(Modifier.align(Alignment.BottomCenter), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PadButton("Select", 32.dp, shape = pill, width = 74.dp) { key(KeyEvent.KEYCODE_BUTTON_SELECT, it) }
            PadButton("Start", 32.dp, shape = pill, width = 74.dp) { key(KeyEvent.KEYCODE_BUTTON_START, it) }
        }
    }
}
